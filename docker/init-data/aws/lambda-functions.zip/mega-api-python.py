import json
import urllib3

def lambda_handler(event, context):
    url = event['url']
    data = event['data']
    http = urllib3.PoolManager()
    encoded_data = json.dumps(data).encode('utf-8')
    headers = {'Content-Type': 'application/json'}

    response = http.request('POST', url, body=encoded_data, headers=headers)

    return {
        'statusCode': response.status,
        'body': response.data.decode('utf-8'),
        'headers': {
            'Content-Type': 'application/json'
        }
    }
