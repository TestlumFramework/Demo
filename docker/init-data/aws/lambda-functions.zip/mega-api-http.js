const http = require('http');

exports.handler = async (event) => {
    const options = event.options;
    const data = event.data;

    return new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => body += chunk);
            res.on('end', () => {
                if (res.headers['content-type'] === 'application/json') {
                    body = JSON.parse(body);
                }
                resolve(body);
            });
        });
        req.on('error', (err) => {
            reject(err);
        });
        req.write(JSON.stringify(data));
        req.end();
    });
};
