const http = require('http');
const https = require('https');

exports.handler = async (event) => {
    const options = event.options;
    const data = event.data;

    const protocol = options.protocol === 'https:' ? https : http;

    return new Promise((resolve, reject) => {
        const req = protocol.request(options, (res) => {
            let body = '';
            res.setEncoding('utf8');
            res.on('data', (chunk) => (body += chunk));
            res.on('end', () => {
                if (res.headers['content-type'] === 'application/json') {
                    body = JSON.parse(body);
                }
                resolve(body);
            });
        });
        req.on('error', (err) => {
            reject(err);
        });
        req.write(JSON.stringify(data));
        req.end();
    });
};
