def lambda_handler(event, context):
    name = event['name']
    subject = event['subject']
    scores = event['scores']

    total = sum(scores)
    count = len(scores)
    average = round(total / count, 2) if count > 0 else 0
    passed = average >= 60

    return {
        'student': name,
        'subject': subject,
        'scores': scores,
        'average': average,
        'passed': passed,
        'status': 'PASSED' if passed else 'FAILED'
    }
